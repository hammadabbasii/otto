@extends( 'frontend.layout' )
@section('title', '')
@section('CSSLibraries')
    <link href="{{ frontend_asset('css/library.css') }}" rel="stylesheet">
    @endsection
    @section('JSLibraries')
    @endsection
    @section('inlineJS')
    @endsection
    @section('content')
            <!------------------------ Header Ends ------------------------------------>

    <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section contentpages">
        <div class="container">
            <div class="row">
                <h1>{{$cms->title}}</h1>
                <div class="col-md-12 nopad">
                    <div class="whtbg content-area-1">
                        <h4>INTRODUCTION:</h4>
                        <p>{{strip_tags($cms->body)}}</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>

    <!------------------------ Footer ------------------------------------>
@endsection