@extends( 'frontend.layout' )
@section('title', '')
@section('CSSLibraries')
    <link href="{{ frontend_asset('css/library.css') }}" rel="stylesheet">
@endsection
@section('JSLibraries')
@endsection
@section('inlineJS')
@endsection
@section('content')
        <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section accountpage">
        <div class="container">
            <div class="row">
                <div class="col-md-2 nopad leftsidebar">
                    <a href="{{frontend_url('signup')}}" class="active">MY ACCOUNT</a>
                     <?php $user=session()->get('user');?>
                    @if(isset($user->id))

                    <a href="{{frontend_url('orders')}}">MY ORDERS</a>
                    <a href="{{frontend_url('wishlist')}}">MY WISHLIST</a>
                    @endif
                </div>
                <div class="col-md-10 nopad">
                    <div class="whtbg content-area-1 contactpage">
                        <h2>MY ACCOUNT</h2>
                        <form name="register" action="signup/add" method="post" id="register">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="col-md-6 padleft">
                            <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
                                <label>FIRST NAME *</label>
                                <input name="first_name" type="text" required="required">
                                @if ( $errors->has('first_name') )
                                    <p class="help-block">{{ $errors->first('first_name') }}</p>
                                @endif
                            </div>
                        </div>

                        <div class="col-md-6 padright">
                            <div class="form-group{{ $errors->has('last_name') ? ' has-error' : '' }}">
                                <label>LAST NAME *</label>
                                <input name="last_name" type="text" required="required">
                                @if ( $errors->has('last_name') )
                                    <p class="help-block">{{ $errors->first('last_name') }}</p>
                                @endif
                            </div>

                        </div>
                        <div class="col-md-6 padleft">
                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label> E-MAIL *</label>
                                <input name="email" type="email" required="required">
                                @if ( $errors->has('email') )
                                    <p class="help-block">{{ $errors->first('email') }}</p>
                                @endif
                            </div>

                        </div>
                        <div class="col-md-6 padright">
                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <label> PASSWORD*</label>
                                <input name="password" type="password" required="required">
                                @if ( $errors->has('password') )
                                    <p class="help-block">{{ $errors->first('password') }}</p>
                                @endif
                            </div>

                        </div>
                        <div class="col-md-6 padleft">
                            <div class="form-group{{ $errors->has('gender') ? ' has-error' : '' }}">
                                <label> GENDER *</label>
                                <select name="gender">
                                    <option value="male" selected>Male</option>
                                    <option value="female">Female</option>
                                </select>
                                @if ( $errors->has('gender') )
                                    <p class="help-block">{{ $errors->first('gender') }}</p>
                                @endif
                            </div>

                        </div>
                        <div class="col-md-6 padright">
                            <div class="form-group{{ $errors->has('phone_number') ? ' has-error' : '' }}">
                                <label> MOBILE NO *</label>
                                <input name="phone_number" type="text" required="required">
                                @if ( $errors->has('phone_number') )
                                    <p class="help-block">{{ $errors->first('phone_number') }}</p>
                                @endif
                            </div>
                        </div>
                        <div class="note">*Required Fields </div>
                        <input value="Save" type="submit">
                        </form>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>
@endsection