
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('JSLibraries'); ?>
        <?php /*<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>*/ ?>
        <?php /*<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>*/ ?>
        <<script src="<?php echo e(frontend_asset('js/library.js')); ?>" type="text/javascript" ></script>
        <script src="<?php echo e(frontend_asset('js/main.js')); ?>" type="text/javascript"></script>
        <?php /*<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>*/ ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('inlineJS'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
            <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section accountpage">
        <div class="container">
            <div class="row">
                <div class="col-md-2 nopad leftsidebar"> <a href="<?php echo e(frontend_url('signup')); ?>">MY ACCOUNT</a> <a href="<?php echo e(frontend_url('orders')); ?>" class="active">MY ORDERS</a> <a href="<?php echo e(frontend_url('wishlist')); ?>">MY WISHLIST</a> </div>
                <div class="col-md-10 nopad">
                    <div class="whtbg content-area-1 contactpage">
                        <table border="0" width="100%;" class="sorted">
                            <tr>
                                <td><h2>MY ORDERS</h2></td>
                                <td></td>
                                <td>


                                   <?php  $user=session()->get('user');

                                    $checkcart=\App\Usercart::where('user_id',$user->id)->first();

                                    ?>
                                    <?php if(isset($checkcart)): ?>
                                    <a href="<?php echo e(frontend_url('checkout')); ?>"><input value="CHECKOUT" type="submit"></a>
                                    <?php endif; ?>

                                </td>
                                <?php /*<td>*/ ?>
                                    <?php /*<select>*/ ?>
                                        <?php /*<option>Last 30 days</option>*/ ?>
                                        <?php /*<option>Last 20 days</option>*/ ?>
                                    <?php /*</select>*/ ?>
                                <?php /*</td>*/ ?>
                                <?php /*<td><input value="Go" type="submit"></td>*/ ?>
                            </tr>
                        </table>
                        <div class="orderpage">
                            <table width="100%">
                                <tr>
                                    <th colspan="2">Product</th>
                                    <th>Unit Price</th>
                                    <th>Quantity</th>
                                    <th>Remove Cart</th>

                                </tr>
                                <?php foreach($usercart as $cartItem): ?>
                                    <?php $record =  $cartItem->product; ?>
                                <tr>
                                    <?php //dd($record) ?>
                                    <td><img src="<?php echo e($record->product_image); ?>" alt=""></td>
                                    <td><?php echo e($record->product_name); ?></td>
                                    <td><?php echo e($record->price); ?></td>
                                    <td><?php echo e($cartItem->quantity); ?></td>
                                        <td><a href="<?php echo e(frontend_url('cartDelete/'.$record->id)); ?>" ><i class="fa fa-trash-o" aria-hidden="true" style="font-size:50px"></i></a></td>

                                </tr>
                                    <?php endforeach; ?>
                            </table>
                        </div>

                        <!--<input value="Save" type="submit">-->
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>