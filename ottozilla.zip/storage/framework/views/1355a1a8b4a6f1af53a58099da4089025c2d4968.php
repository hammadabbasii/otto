<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JSLibraries'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inlineJS'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section accountpage">
        <div class="container">
            <div class="row">
                <div class="col-md-2 nopad leftsidebar">
                    <a href="<?php echo e(frontend_url('signup')); ?>" class="active">MY ACCOUNT</a>
                     <?php $user=session()->get('user');?>
                    <?php if(isset($user->id)): ?>

                    <a href="<?php echo e(frontend_url('orders')); ?>">MY ORDERS</a>
                    <a href="<?php echo e(frontend_url('wishlist')); ?>">MY WISHLIST</a>
                    <?php endif; ?>
                </div>
                <div class="col-md-10 nopad">
                    <div class="whtbg content-area-1 contactpage">
                        <h2>MY ACCOUNT</h2>
                        <form name="register" action="signup/add" method="post" id="register">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="col-md-6 padleft">
                            <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                <label>FIRST NAME *</label>
                                <input name="first_name" type="text" required="required">
                                <?php if( $errors->has('first_name') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-6 padright">
                            <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                <label>LAST NAME *</label>
                                <input name="last_name" type="text" required="required">
                                <?php if( $errors->has('last_name') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-md-6 padleft">
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label> E-MAIL *</label>
                                <input name="email" type="email" required="required">
                                <?php if( $errors->has('email') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('email')); ?></p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-md-6 padright">
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label> PASSWORD*</label>
                                <input name="password" type="password" required="required">
                                <?php if( $errors->has('password') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-md-6 padleft">
                            <div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                                <label> GENDER *</label>
                                <select name="gender">
                                    <option value="male" selected>Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <?php if( $errors->has('gender') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('gender')); ?></p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-md-6 padright">
                            <div class="form-group<?php echo e($errors->has('phone_number') ? ' has-error' : ''); ?>">
                                <label> MOBILE NO *</label>
                                <input name="phone_number" type="text" required="required">
                                <?php if( $errors->has('phone_number') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('phone_number')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="note">*Required Fields </div>
                        <input value="Save" type="submit">
                        </form>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>