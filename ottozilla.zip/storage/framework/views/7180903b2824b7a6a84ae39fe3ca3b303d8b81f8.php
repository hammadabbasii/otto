
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('JSLibraries'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('inlineJS'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
            <!------------------------ Header Ends ------------------------------------>

    <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section contentpages">
        <div class="container">
            <div class="row">
                <h1>Site Map/ </h1>
                <div class="col-md-12 nopad">
                    <div class="whtbg content-area-1">
                        <h1>Site Map/ </h1>
                        <div class="row">
                            <div class="col-md-1 padleft"></div>
                            <div class="col-md-2 padleft">
                                <h4 style="color:deepskyblue">Information</h4>
                                <ul>
                                    <li><a  href="<?php echo e(frontend_url('aboutus')); ?>">About Us</a></li>
                                    <li><a  href="<?php echo e(frontend_url('contactus')); ?>">Contact Us</a></li>
                                    <li><a  href="<?php echo e(frontend_url('terms')); ?>">Terms & Conditions</a></li>
                                    <li><a  href="<?php echo e(frontend_url('privacy')); ?>">Privacy Policy</a></li>
                                    <li><a  href="<?php echo e(frontend_url('orderandreturn')); ?>">Orders and Returns</a></li>
                                    <li><a  href="<?php echo e(frontend_url('sitemap')); ?>">Site Map</a></li>
                                </ul>
                            </div>
                            <div class="col-md-2 padleft">
                                <h4 style="color:deepskyblue">Why buy from us</h4>
                                <ul>
                                    <li><a href="<?php echo e(frontend_url('shippingoption')); ?>">Shipping Options</a></li>
                                    <li><a href="<?php echo e(frontend_url('help')); ?>">Help & FAQs</a></li>
                                </ul>
                            </div>
                            <div class="col-md-2 padleft">
                                <h4 style="color:deepskyblue">My account</h4>
                                <ul>
                                    <li><a href="<?php echo e(frontend_url('login')); ?>">Sign In</a></li>
                                    <li><a href="<?php echo e(frontend_url('wishlist')); ?>">My Wishlist</a></li>
                                    <?php
                                    $user=session()->get('user');
                                    ?>
                                    <?php if($user): ?>
                                        <li><a href="<?php echo e(frontend_url('orders')); ?>">View Cart</a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(frontend_url('login')); ?>">View Cart</a></li>
                                    <?php endif; ?>
                                    <?php if($user): ?>
                                        <li><a href="<?php echo e(frontend_url('checkout')); ?>">Check out</a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(frontend_url('login')); ?>">Check out</a></li>
                                    <?php endif; ?>
                                    <?php /*<li><a href="#">Track My Order</a></li>*/ ?>
                                </ul>
                            </div>
                            <div class="col-md-2 padleft">
                                <h4 style="color:deepskyblue">Assistance</h4>
                                <ul>
                                    <li><a href="<?php echo e(frontend_url('shipping')); ?>">Shipping Information</a></li>
                                    <li><a href="<?php echo e(frontend_url('needhelp')); ?>">Need help?</a></li>
                                    <li><a href="<?php echo e(frontend_url('customersupport')); ?>">Customer Support</a></li>
                                </ul>
                            </div>
                            <div class="col-md-2 padleft">
                                <h4 style="color:deepskyblue">Useful links</h4>
                                <ul>
                                    <li><a href="<?php echo e(frontend_url('pricing/policy')); ?>">Pricing Policy</a></li>
                                    <li><a href="<?php echo e(frontend_url('shipping/policy')); ?>">Shipping Policy</a></li>
                                    <li><a href="<?php echo e(frontend_url('siteinformation')); ?>">Site Information</a></li>
                                    <li><a href="<?php echo e(frontend_url('satisfaction')); ?>">Your Satisfaction</a></li>
                                </ul>
                            </div>
                            <div class="col-md-1 padleft"></div>
                    </div>
                        <div class="row">
                            <div class="col-md-2"></div>
                        <div class="col-md-8"><img src="<?php echo e(URL::to('/')); ?>/public/images/sitemap.jpg" alt=""></div>
                        <div class="col-md-2"></div>
                        </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>

    <!------------------------ Footer ------------------------------------>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>