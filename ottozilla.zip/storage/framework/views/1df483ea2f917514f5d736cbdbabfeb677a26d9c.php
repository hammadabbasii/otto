<?php /*
<div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('first_name', 'First Name', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('first_name', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('first_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('last_name', 'Last Name', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('last_name', old('last_name'), ['class' => 'form-control'])); ?>

    <?php if( $errors->has('last_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('email', 'Email', ['class'=>'control-label'])); ?>

    <?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('email') ): ?>
        <p class="help-block"><?php echo e($errors->first('email')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('password', 'Password', ['class'=>'control-label'])); ?>

    <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

    <?php if( $errors->has('password') ): ?>
        <p class="help-block"><?php echo e($errors->first('password')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('phone', 'Phone', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('phone') ): ?>
        <p class="help-block"><?php echo e($errors->first('phone')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('company_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('company_name', 'Company Name', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('company_name', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('company_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('company_name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('address', 'Address', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('address', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('address') ): ?>
        <p class="help-block"><?php echo e($errors->first('address')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('city', 'City', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('city', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('city') ): ?>
        <p class="help-block"><?php echo e($errors->first('city')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('state', 'State', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('state', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('state') ): ?>
        <p class="help-block"><?php echo e($errors->first('state')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('country', 'Country', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('country', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('country') ): ?>
        <p class="help-block"><?php echo e($errors->first('country')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('postal_code') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('postal_code', 'Postal Code', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('postal_code', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('postal_code') ): ?>
        <p class="help-block"><?php echo e($errors->first('postal_code')); ?></p>
    <?php endif; ?>
</div>

<?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

<?php echo e(Html::link( backend_url('user'), 'Cancel', ['class' => 'btn btn-default'])); ?>*/ ?>


<div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('first_name', 'First Name *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                 <?php echo e(Form::text('first_name', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('first_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('last_name', 'Last Name', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('last_name', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('last_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('email', 'Email', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('email', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('email') ): ?>
                <p class="help-block"><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('password', 'Password', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::password('password',['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('password') ): ?>
                <p class="help-block"><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('address', 'Address', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('address', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('address') ): ?>
                <p class="help-block"><?php echo e($errors->first('address')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('city', 'City', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('city', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('city') ): ?>
                <p class="help-block"><?php echo e($errors->first('city')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('state', 'State', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('state', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('state') ): ?>
                <p class="help-block"><?php echo e($errors->first('state')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('country', 'Country', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('country', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('country') ): ?>
                <p class="help-block"><?php echo e($errors->first('country')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('postal_code') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('postal_code', 'Postal code', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('postal_code', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('postal_code') ): ?>
                <p class="help-block"><?php echo e($errors->first('postal_code')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('phone_no') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('phone_no', 'Phone no', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('phone_no', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('phone_no') ): ?>
                <p class="help-block"><?php echo e($errors->first('phone_no')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('company_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('company_name', 'Company name', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('company_name', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('company_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('company_name')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('company_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('company_name', 'Company name', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::select('size', ['L' => 'Large', 'S' => 'Small'],null,['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('company_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('company_name')); ?></p>
        <?php endif; ?>
</div>


<div class="form-group<?php echo e($errors->has('profile_picture') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('profile_picture', 'Profile picture', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::file('profile_picture', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('profile_picture') ): ?>
                <p class="help-block"><?php echo e($errors->first('profile_picture')); ?></p>
        <?php endif; ?>
</div>


<div class="ln_solid"></div>
<div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                <?php echo e(Html::link( backend_url('user'), 'Cancel', ['class' => 'btn btn-default'])); ?>

        </div>
</div>

