
<div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('interest_name', 'Interest Title', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('interest_name', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('interest_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('interest_name')); ?></p>
    <?php endif; ?>
</div>


<div class="ln_solid"></div>
<div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                <?php echo e(Html::link( backend_url('user'), 'Cancel', ['class' => 'btn btn-default'])); ?>

        </div>
</div>

