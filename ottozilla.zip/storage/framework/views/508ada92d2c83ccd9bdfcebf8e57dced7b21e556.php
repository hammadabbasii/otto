
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
<link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JSLibraries'); ?>
<?php /*<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>*/ ?>
<?php /*<!------------------------ Jquery CDN ------------------------------------>*/ ?>
<?php /*<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>*/ ?>
<!------------------------ Javascript ------------------------------------>
<script src="<?php echo e(frontend_asset('js/library.js')); ?>" type="text/javascript" ></script>
<script src="<?php echo e(frontend_asset('js/main.js')); ?>" type="text/javascript"></script>
<!------------------------ WOW Animation CDN------------------------------------>
<link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inlineJS'); ?>
    <script>

        function markUnmarkFavourite(userId,productId)
        {
            anchorHtml = '';
            //Ajax Call to activate function
            $.ajax({
                type: "POST",
                url: '<?php echo URL::to('/');?>/api/product/wishlist',
                data: {
                    user_id:userId,
                    product_id:productId
                },
                success: function(data)
                {
                    if(data.Response=='Success' )
                    {


                        if(data.Result.status== 1) {


                            anchorHtml =' <a onclick="markUnmarkFavourite('+userId+','+productId+')" class="added_to_favourites" aria-hidden="true" style="font-size: 20px; cursor: pointer"><i class="fa fa-heart" >  </i></a>';

                        } else {


                            anchorHtml =' <a onclick="markUnmarkFavourite('+userId+','+productId+')" class="added_to_favourites" aria-hidden="true" style="font-size: 20px; cursor: pointer"><i class="fa fa-heart-o" >  </i></a>';

                        }

                        $('#wishlistBtn_'+productId).html(anchorHtml);

                    }

                }
            });

            $('#CloseButton').trigger('click');

        }


    </script>
<script>new WOW().init();</script>
<script>$(document).ready(function() {
    $('.tabs-menu').each(function(){
        $('li:first-child a').click();
    });
});</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?><section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!-------------------------------------------Thumb Slider Started------------------------------------>
    <section class="slider">
        <thumbslider>
            <div class="slider-thumb">

                <!-- Large Slide -->
                <div class="item-slider">
                    <?php foreach( $slider as $record ): ?>
                    <div class="slick-slider-item"> <img src="<?php echo e(URL::to('/')); ?>/public/images/slider/<?php echo e($record->slider_images); ?>" alt="banner-01"> </div>
                    <?php endforeach; ?>
                </div>
                <!-- Thumb Slides -->

                <div class="slidercenter">
                    <div class="thslider">
                        <div class="thumb-slider">
                            <?php foreach( $slider as $record ): ?>
                            <div class="slick-slider-item"> <img src="<?php echo e(URL::to('/')); ?>/public/images/slider/<?php echo e($record->slider_images); ?>" alt="banner-thumb1"> </div>
                                <?php endforeach; ?>
                            <!--/slick-slider-item-->
                        </div>
                    </div>
                </div>
            </div>
        </thumbslider>
    </section>
<?php
$i=1;
?>
    <!-------------------------------------------Thumb Slider Started------------------------------------>
    <?php foreach( $allCategoriesFromDB as $category ): ?>
    <section class="section hometabbing wow fadeInUp">
        <div class="container nopad">
            <div class="cat_large_box whtbg">
                <div class="toparea1">

                    <h4><?php echo e($category->category_name); ?></h4>

                    <div class="clear"></div>
                </div>
                <div class="cat_mid_area">

                    <tabs>

                        <div id="tabs-container">

                            <ul class="tabs-menu" id="tabs-menu">
                                <?php
                                $j=$i;
                                ?>
                                <?php foreach( $category->subcategories as $subcategory ): ?>
                                        <li><a href="#tab-<?php echo e($j); ?>" class="tabLink"><?php echo e($subcategory->category_name); ?></a></li>
                                <?php $j++; ?>

                                <?php endforeach; ?>
                                    <li><a href="<?php echo e(frontend_url('category/'.$category->id)); ?>">More</a></li>
                            </ul>

                            <div class="tab">
                                <?php foreach( $category->subcategories as $subcategory ): ?>
                                    <!------------------------ Fruits ------------------------------------>
                                    <div id="tab-<?php echo e($i); ?>" class="tab-content">

                                    <div class="tabbing_banner"><img style="width:1170px;height: 237px " src="<?php echo e($category->image); ?>" alt=""></div>
                                    <div class="homeproducts homeproduct">
                                        <?php foreach($subcategory->getProductsByBrand()->limit(4)->get() as $product): ?>
                                        <div class="col-md-3">


                                            <div class="product_image"> <a href="<?php echo e(frontend_url('productdetails/'.$category->id.'/'.$product->id)); ?>"><img style="" src="<?php echo e($product->product_image); ?>" alt="product"></a></div>
                                            <div class="product_title"><a href="<?php echo e(frontend_url('productdetails/'.$category->id.'/'.$product->id)); ?>"><?php echo e($product->product_name); ?></a></div>
                                            <?php
                                            $isFav= $product->is_in_wishlist;
                                            $user = session()->get('user');
                                            ?>
                                            <?php if(isset($user)): ?>
                                                <?php
                                                $user = session()->get('user');
                                                $userId = $user->id > 0 ? $user->id : 0;

                                                $favourites = $isFav;
                                                $anchorClass= "added_to_favourites";
                                                $iconClass= "fa fa-heart-o";
                                                $text = "Add to Favourites";
                                                if($favourites) {
                                                    $anchorClass= "added_to_favourites";
                                                    $iconClass= "fa fa-heart";
                                                    $text = "Added to Favourites";
                                                }
                                                ?>

                                                <span id="wishlistBtn_<?php echo  $product->id ?>">
                    <a onclick="markUnmarkFavourite('<?php echo $userId; ?>', '<?php echo  $product->id ?>' );"  class="<?= $anchorClass ?>" style="font-size: 20px; cursor: pointer;"><i class="<?= $iconClass ?>" aria-hidden="true" ></i></a>
                        </span>
                                                <?php endif; ?>
                                            <div class="product_price"><span> BHD</span> <?php echo e($product->price); ?></div>
                                            <?php /*<h1>Wishlist Implement Soon</h1>*/ ?>
                    <br><span>
                     <?php $user = session()->get('user'); ?>
                         <?php if(isset($user)): ?>
                             <form name="add_to_cart" action="addtocart" method="post" id="add_to_cart">
                                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                 <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
                                 <input type="hidden" value="<?php echo e($product->id); ?>" name="product_id">
                                 <input value="add to cart" type="submit" class="cartbtn">
                             </form>
                             <?php endif; ?>
                    </span> </div>
                                        <?php endforeach; ?>


                                    </div>
                                </div>

                                <?php $i++; ?>
                                <?php endforeach; ?>
                                <!------------------------ Fruits------------------------------------>

                            </div>
                        </div>

                    </tabs>

                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <?php endforeach; ?>

    <section class="section hometabbing wow fadeInUp">
        <div class="container nopad">
            <div class="cat_large_box whtbg">
                <div class="toparea1">
                    <?php foreach( $advertisement as $record ): ?>
                    <div class="col-md-4"><img src="<?php echo e(URL::to('/')); ?>/public/images/advertisement/<?php echo e($record->image1); ?>" alt=""></div>
                    <div class="col-md-8 padleft shipng"><img src="<?php echo e(URL::to('/')); ?>/public/images/advertisement/<?php echo e($record->image2); ?>" alt=""></div>
                        <?php endforeach; ?>
                </div>
                <div class="clearfix"><br>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>