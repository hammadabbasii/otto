
<div class="form-group<?php echo e($errors->has('CategoryName') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('CategoryName', 'Category Title', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('CategoryName', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('CategoryName') ): ?>
        <p class="help-block"><?php echo e($errors->first('CategoryName')); ?></p>
    <?php endif; ?>
</div>

<?php 
#echo "hellos".$subcategory->parent_id;die();
?>
<div class="form-group<?php echo e($errors->has('parent_id') ? ' has-error' : ''); ?>">
    <?php echo Form::Label('parent_id', 'Parent Category:'); ?>

  <select class="form-control" name="parent_id">
  
  <?php
  if(isset($subcategory->parent_id))
  {
 	$thisParentId	=	$subcategory->parent_id;
  	foreach($category as $item)
	{
		$thisCategoryId	=	$item->id;
		if($thisCategoryId == $thisParentId)
		{
			echo '<option value="'.$item->id.'" selected>'.$item->CategoryName.'</option>';
		}
		else
		{
  			echo '<option value="'.$item->id.'">'.$item->CategoryName.'</option>';
		}
	}
  }
  else 
  foreach($category as $item)
	{
		
  		echo '<option value="'.$item->id.'">'.$item->CategoryName.'</option>';
	}
  	
  ?>

  </select>
</div>

<div class="ln_solid"></div>
<div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                <?php echo e(Html::link( backend_url('user'), 'Cancel', ['class' => 'btn btn-default'])); ?>

        </div>
</div>

