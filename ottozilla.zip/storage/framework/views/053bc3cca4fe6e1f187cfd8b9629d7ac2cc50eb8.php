<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>
<div class="wrap">    

    <h1 class="entry-title"><?php echo e($cms->title); ?></h1>
    <div class="rht"> <img src="<?php echo e(frontend_asset('images/terms.jpg')); ?>" alt=""></div>
    <?php echo html_entity_decode($cms->body); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>