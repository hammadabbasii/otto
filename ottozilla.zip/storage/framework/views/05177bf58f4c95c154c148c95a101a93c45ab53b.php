<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
                        <form role="form" method="POST">
						   <h1>Login Form</h1>
                        <?php echo e(csrf_field()); ?>

                            <fieldset>
                            <?php if( $errors->count() ): ?>
                                <div class="alert alert-danger">
                                    <?php echo implode('<br />', $errors->all()); ?>

                                </div>
                            <?php endif; ?>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus value="<?php echo e(old('email')); ?>">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me" <?php echo e(old('remember') ? ' checked="checked"' : ''); ?>>Remember Me
                                    </label>
                                </div>

                                <button type="submit" class="btn btn-lg btn-success btn-block">Login</button>

                                <div class="text-center magt-10">
                                    <a href="<?php echo e(backend_asset('reset-password')); ?>">Forgot password?</a>
                                </div>
                            </fieldset>
                        </form>
                    </section>
					</div>
					</div>
					</div>
					
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app-guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>