<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('CSSLibraries'); ?>
    <!-- DataTables CSS -->
    <link href="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSLibraries'); ?>
    <!-- DataTables JavaScript -->
    <script src="<?php echo e(backend_asset('libraries/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inlineJS'); ?>
    <script type="text/javascript">
    <!-- Datatable -->
      $(document).ready(function() {
      $('#datatable').dataTable();
    });

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Product <small>Some examples to get you started</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

              <?php /*<?php echo $__env->make('backend.layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>

            <div class="row">

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Product <small>Product listing</small></h2>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <?php echo $__env->make( 'backend.layouts.notification_message' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                      <tr>
                        <th>Id</th>
                        <th>Product Image</th>
                        <th>Product Name</th>
                        <th>Product Detail</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Created At</th>
                        <th>Action</th>
                      </tr>
                      </thead>


                      <tbody>
                      <?php foreach( $product as $record ): ?>
                        <tr class="">

                          <td><?php echo e($record->id); ?></td>
                          <td><img width="70%" src="<?php echo e($record->ProductImage); ?>" /></td>
                          <td><?php echo e($record->ProductName); ?></td>
                          <td><?php echo e($record->ProductDescription); ?></td>
                          <td><?php echo e($record->Price); ?></td>
                          <td><?php echo e($record->Quantity); ?></td>
                          <td><?php echo e($record->created_at); ?></td>
                          <td>
                            <a href="<?php echo e(backend_url('product/edit/'.$record->id)); ?>" class="btn btn-xs btn-primary edit" style="float: left;"><i class="fa fa-pencil"></i></a>

                            <?php echo Form::model($record, ['method' => 'delete', 'url' => 'backend/product/'.$record->id, 'class' =>'form-inline form-delete']); ?>

                            <?php echo Form::hidden('id', $record->id); ?>

                            <?php echo Form::button('<i class="fa fa-trash"></i>', ['class' => 'btn btn-xs btn-danger delete', 'name' => 'delete_modal', 'type' => 'submit']); ?>

                            <?php echo Form::close(); ?>

                          </td>
                        </tr>
                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>