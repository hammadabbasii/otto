<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('CSSLibraries'); ?>
<!-- DataTables CSS -->
<link href="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

<!-- DataTables Responsive CSS -->
<link href="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSLibraries'); ?>
<!-- DataTables JavaScript -->
<script src="<?php echo e(backend_asset('libraries/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inlineJS'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
//echo '<pre>';
// print_r($userLogs);
?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo e($users['first_name']); ?> Profile</h3>
            </div>


        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>User Report <small></small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>

                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                            <div class="profile_img">
                                <div id="crop-avatar">
                                    <!-- Current avatar -->
                                    <?php echo e(Html::image('public/images/'.$users['profile_picture'] , '', array( 'width' => 200, 'height' => 200 ))); ?>

                                </div>
                            </div>
                            <h3><?php echo e($users['first_name'].' '.$users['last_name']); ?></h3>

                            <ul class="list-unstyled user_data">
                                <li><i class="fa fa-map-marker user-profile-icon"></i> <?php echo e($users['address'] != '' ? $users['address'] : 'N/A'); ?>

                                </li>

                                <li>
                                    <i class="fa fa-briefcase user-profile-icon"></i> <?php echo e($users['email'] != '' ? $users['email'] : 'N/A'); ?>

                                </li>


                            </ul>

                            <?php /*<a class="btn btn-success"><i class="fa fa-edit m-right-xs"></i>Edit Profile <?php echo e($users['first_name'                            ]); ?></a>                                     */ ?>
                            <br />
                        </div>
                        <div class="col-md-9 col-sm-9col-xs-12">



                            <div class="" role="tabpanel" data-example-id="togglable-tabs">
                                <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                                    <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Recent Activity</a>
                                    </li>
                                    <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Profile</a>
                                    </li>
                                </ul>
                                <div id="myTabContent" class="tab-content">
                                    <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="    home-tab">

                                        <!-- start recent activity -->
                                        <ul class="messages">

                                            <?php foreach( $userLogs as $log ): ?>
                                            <li>
                                                <img src="<?php echo e(asset('public/images/img.jpg')); ?>" class="avatar" alt="Avatar">
                                                <div class="message_date">
                                                    <h3 class="date text-info"><?php echo e(Carbon\Carbon::parse($log['created_at'])->format('d')); ?></h3>
                                                    <p class="month"><?php echo e(Carbon\Carbon::parse($log['created_at'])->format('M')); ?></p>
                                                </div>
                                                <div class="message_wrapper">
                                                    <h4 class="heading"><?php echo e($log['user']['first_name']); ?></h4>
                                                    <blockquote class="message"><?php echo e($log['log_content']); ?></blockquote>
                                                    <br />
                                                    <p class="url">
                                                        <span class="fs1 text-info" aria-hidden="true" data-icon=""></span>

                                                    </p>
                                                </div>
                                            </li>

                                            <?php endforeach; ?>
                                        </ul>
                                        <!-- end recent activity -->

                                    </div>

                                    <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th colspan="2" >User Detail</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>First Name</td>
                                                    <td><?php echo e($users['first_name']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Last Name</td>
                                                    <td><?php echo e($users['last_name']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Email Address</td>
                                                    <td><?php echo e($users['email']); ?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td>Address</td>
                                                    <td><?php echo e($users['address'] != '' ? $users['address'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>City</td>
                                                    <td><?php echo e($users['city'] != '' ? $users['city'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>State</td>
                                                    <td><?php echo e($users['state'] != '' ? $users['state'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Country</td>
                                                    <td><?php echo e($users['country'] != '' ? $users['country'] : 'N/A'); ?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td>User Status</td>
                                                    <td><?php echo e($users['status'] == '1' ? 'Active' : 'Inactive'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Created At</td>
                                                    <td><?php echo e(Carbon\Carbon::parse($users['created_at'])->format('d-M-Y H:i:s')); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Updated At</td>
                                                    <td><?php echo e(Carbon\Carbon::parse($users['updated_at'])->format('d-M-Y H:i:s')); ?></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>