<div class="container">
    <div class="row">
        <div class="col-md-4 padleft logo"><a href="<?php echo e(frontend_url('index')); ?>"><img src="<?php echo e(frontend_asset('images/logo.png')); ?>" alt="logo"></a></div>
        <div class="col-md-5 searchbar nopad">
            <form name="search" action="<?php echo e(frontend_url('search')); ?>" method="post" id="search">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php /*<input placeholder="Search" name="searchtxt" type="text">*/ ?>
                <select class="js-example-basic-single" data-placeholder="Search" placeholder="Search" name="category_id">
                    <?php foreach( \App\Category::where('parent_id',0)->with('subcategories')->get() as $category ): ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; ?>
                </select>

                <input value="Search" type="submit">
            </form>
        </div>
        <?php
        $user = session()->get('user');
        ?>
        <?php if(isset($user)): ?>
            <?php $cartcount=\App\Usercart::where('user_id',$user->id)->get()->count();

            ?>
        <div class="col-md-1 headercart"> <span class="count"><?php echo e($cartcount); ?></span>

            <div class="clearfix"></div>
            Cart </div>
        <?php endif; ?>
        <div class="col-md-2 headerlinks">

                <?php
                $user = session()->get('user');
                ?>
                <?php if(isset($user)): ?>
                        <ul>
                        <li><a href="<?php echo e(frontend_url('logout')); ?>">Logout</a></li>
                            <li><a href="<?php echo e(frontend_url('signup')); ?>">Join</a></li>
                            <span class="smartmarttag"><?php echo e($user->first_name); ?></span>


                        </ul>
                    <?php endif; ?>
                    <?php if(!isset($user)): ?>
                        <ul>
                <li><a href="<?php echo e(frontend_url('login')); ?>">Sign in</a></li>
                <li><a href="<?php echo e(frontend_url('signup')); ?>">Join</a></li>
                            </ul>
                        <span class="smartmarttag">SmartMart</span>
                 <?php endif; ?>


        </div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-9 menu-header">
            <ul>
                <li><a href="<?php echo e(frontend_url('index')); ?>">home</a></li>
                <?php foreach( \App\Category::where('parent_id',0)->with('subcategories')->limit(4)->get() as $category ): ?>
                <li><a href="<?php echo e(frontend_url('category/'.str_slug($category->id))); ?>"><?php echo e($category->category_name); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>
