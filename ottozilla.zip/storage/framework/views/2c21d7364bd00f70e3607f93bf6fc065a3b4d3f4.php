
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(frontend_asset('css/daterangepicker.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JSLibraries'); ?>
    <<script src="<?php echo e(frontend_asset('js/library.js')); ?>" type="text/javascript" ></script>
    <script src="<?php echo e(frontend_asset('js/main.js')); ?>" type="text/javascript"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="<?php echo e(frontend_asset('js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(frontend_asset('js/daterangepicker.js')); ?>" type="text/javascript"></script>
    <!-- Custom Theme Style -->
    <script>new WOW().init();</script>
    <!------------------------ WOW Animation CDN------------------------------------>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('inlineJS'); ?>
            <!-- bootstrap-daterangepicker -->




    <script>
        $(document).ready(function() {
//            $('#reservation').daterangepicker(null, function(start, end, label) {
//                console.log(start.toISOString(), end.toISOString(), label);
//            });

            var end = moment();
            $('#reservation-time').daterangepicker({
                timePicker: true,
                timePickerIncrement: 10,
                singleDatePicker: true,
                minDate: end,
                locale: {
                    format: 'YYYY-MM-DD h:mm:ss'
                }
            });

            $('.dropdown-menu').hide();


//            $('#reservation-time2').daterangepicker({
//                timePicker: true,
//                singleDatePicker: true,
//                timePickerIncrement: 30,
//                locale: {
//                    format: 'MM-DD-YYYY h:mm:ss'
//                }
//            });



        });
    </script>
    <!-- /bootstrap-daterangepicker -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
            <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <section class="section checkout contactpage">
        <div class="container">
            <div class="row">
                <form name="order" action="order/add" method="post" id="order">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>CHECKOUT</h1>
                <div class="col-md-6 padleft">
                    <div class="whtbg content-area-1">

                        <?php /*<h3>1. User Information</h3>*/ ?>

                        <?php /*<div class="col-md-6 padleft">*/ ?>
                            <?php /*<label>FIRST NAME *</label>*/ ?>
                            <?php /*<input name="fname" type="text">*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-6 padright">*/ ?>
                            <?php /*<label>LAST NAME *</label>*/ ?>
                            <?php /*<input name="lname" type="text">*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-12 nopad">*/ ?>
                            <?php /*<label>EMAIL ADDRESS *</label>*/ ?>
                            <?php /*<input name="email" type="email">*/ ?>
                        <?php /*</div>*/ ?>

                        <h3>1. NEW ADDRESS</h3>
                        <div class="checkboxbtns">

                                <label for="f-option"><a href="<?php echo e(frontend_url('addAddress')); ?>">  <i class="fa fa-plus" aria-hidden="true" style="font-size: 20px"></i> ADD NEW ADDRESS </a></label><br><br>
                        </div>
                        <h3>2. PREVIOUS ADDRESS</h3>
                        <div class="checkboxbtns">
                            <ul>
                                <li>
                                    <input type="radio" id="f-option" name="address">
                                    <label for="f-option">Deliver to this Address</label>
                                    <div class="check"></div>
                                </li>
                                <?php /*<li>*/ ?>
                                    <?php /*<input type="radio" id="s-option" name="selector">*/ ?>
                                    <?php /*<label for="s-option">Deliver to this Address</label>*/ ?>
                                    <?php /*<div class="check">*/ ?>
                                        <?php /*<div class="inside"></div>*/ ?>
                                    <?php /*</div>*/ ?>
                                <?php /*</li>*/ ?>
                            </ul>
                        </div>
                        <div class="clearfix"><br>
                            <br>
                        </div>
                        <div class="col-md-12 nopad">
                            <label>SELECT AN ADDRESS FROM ADDRESS BOOK.</label>
                            <select name="address_id" required="required">

                                    <?php foreach($useraddress as $addItem): ?>
                                <option value="<?php echo e($addItem->id); ?>"> <?php echo e($addItem->country); ?> <?php echo e($addItem->street_name); ?> <?php echo e($addItem->building_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="clearfix"><br>
                            <br>
                        </div>
                        <h3>2. DELIVERY TIME</h3>
                        <p>Select preferred time</p>
                                            <input type="text" name="delivery_datetime" id="reservation-time" class="form-control" value="01-01-2017"/>


                        <div class="clearfix"><br>
                            <br>
                        </div>
                        <h3>3. PAYMENT METHOD</h3>
                        <div class="checkboxbtns">
                            <ul>
                                <li>
                                    <input checked=checked type="radio" id="s-option" name="payment_method" value="cc">
                                    <label for="s-options">Cash On Delivery</label>
                                    <div class="check"></div>
                                </li>
                                <?php /*<li>*/ ?>
                                <?php /*<input type="radio" id="s-option" name="selector">*/ ?>
                                <?php /*<label for="s-option">Deliver to this Address</label>*/ ?>
                                <?php /*<div class="check">*/ ?>
                                <?php /*<div class="inside"></div>*/ ?>
                                <?php /*</div>*/ ?>
                                <?php /*</li>*/ ?>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="col-md-6 padright">
                    <div class="whtbg content-area-1 registered_customers">
                        <h3>5. REVIEW YOUR ORDER</h3>
                        <table  class="orderreview" width="100%">
                            <tr>
                                <th>Your Product</th>
                                <th>Item Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                            <?php $total=0;?>
                            <?php foreach($usercart as $cartItem): ?>
                                <?php $record =  $cartItem->product; ?>
                            <tr>
                                <td><?php echo e($record->product_name); ?></td>
                                <td><?php echo e($record->price); ?></td>
                                <td><?php echo e($cartItem->quantity); ?></td>
                                <?php
                                $subtotal=$record->price*$cartItem->quantity;
                                      $total =$subtotal+$total;

                                $ids[]=$record->id;
                                $quantity[]=$cartItem->quantity;
                                $idsList = implode(',', $ids);
                                $quantityList = implode(',', $quantity);




                                ?>
                                <td><?php echo e($subtotal); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                          <input type="hidden" value="<?php echo e($idsList); ?>" name="items_ids">
                        <input type="hidden" value="<?php echo e($quantityList); ?>" name="quantities">
                        <?php $user=Session::get('user'); ?>
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
                        <div class="clearfix"><br></div>

                        <div class="col-md-3"></div>

                        <div class="col-md-9 noapad">
                            <table  class="subtotal" width="100%">

                                <tr>
                                    <?php /*<td>Subtotal</td>*/ ?>
                                    <?php /*<td>BD1.400</td>*/ ?>
                                </tr>
                                <tr>
                                    <td>Home Delivery Charges</td>
                                    <td>Free</td>
                                </tr>

                                <tr>
                                    <td>Total</td>
                                    <td>BD <?php echo e($total); ?></td>
                                </tr>


                            </table>

                            <?php /*<div class="forgetitem">Forgot an item? <a href="javascript::">Edit Your Cart</a></div>*/ ?>

                        </div>
                        <div class="clearfix"></div>
                        <hr />



                        <div class="clearfix"></div>

                        <div class="subscribe">

                            <h4>PRODUCT SUBSTITUTUTION PREFERENCE</h4>


                            <input type="radio" name="Substitute" value="Substitute"> <span>Substitute my items</span>


                            <ul>
                                <li>We'll find a suitable alternative if your ordered item is unavailable</li>
                                <li>We’ll call to confirm substitutes and price variances if any</li>
                                <li>If you don't want it, just hand it back to your driver for a full refund</li>
                            </ul>

                            <input type="radio" name="Substitute" value="NotSubstitute"> <span>Do not substitute my items</span>

                            <ul>
                                <li>You will not receive an alternative if the product is unavailable </li>
                            </ul>

                        </div>

                        <div class="clearfix"><br/></div>

                        <div class="commnets"> <label>Comments</label>
                            <textarea name="additional_notes" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" id="mesg" aria-invalid="false"></textarea></div>


                        <div class="clearfix"><br></div>
                        <div class="pull-right">
                            <input value="Place Order" type="submit">
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                </form>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>