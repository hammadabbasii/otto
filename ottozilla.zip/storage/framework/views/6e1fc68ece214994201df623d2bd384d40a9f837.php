<?php $__env->startSection('title', 'Trips'); ?>

<?php $__env->startSection('CSSLibraries'); ?>
<!-- DataTables CSS -->
<link href="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

<!-- DataTables Responsive CSS -->
<link href="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSLibraries'); ?>
<!-- DataTables JavaScript -->
<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script src="<?php echo e(backend_asset('libraries/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.js')); ?>"></script>


<script type="text/javascript">

function getJoinees(TripId)
        {
        $('#popup_heading').html('Trip Joinees');
        var PopupBody = '';
        $.ajax({
        type: "GET",
                url: "/tripcrasher/backend/trips/getJoinees/" + TripId,
                data: {},
                success: function(data)
                {
                var incomingData = JSON.parse((data))
                        console.log(incomingData)
                        for (var i = 0; i < (incomingData.length); i++)
                {
                var fullName = incomingData[i]['full_name'];
                var profilePic = incomingData[i]['profile_picture'];
                if ($.trim(fullName == ''))
                {
                fullName = " " + incomingData[i]['first_name'] + " " + incomingData[i]['last_name']; ;
                }
                PopupBody = PopupBody + '<tr><td style="padding:10px"><img src="' + profilePic + '" width="50" ></td><td>' + fullName + '</td></tr>';
                }

                $('#popup_body').html(PopupBody);
                }
        });
        var footerData = '';
        $('#PopupFooter').html(footerData);
        }



function ShowMap(placeName, placeLatitude, placeLongitude)
        {
        //$('#myModal').css('width','600');
        $('#myModalInner').css('width', '650');
        $('#popup_heading').html('Location');
        // var PopupBody	=	'<iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD-SF9cO7YaQP9lVTEtXmlFJVpaov6D3Fw&q='+placeLatitude+','+placeLongitude+'" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>';

        // var PopupBody	=	'<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d14482.748950634612!2d'+placeLongitude+'!3d'+placeLatitude+'!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1482514201112" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>';


        var PopupBody = '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14482.116194992053!2d' + 67.073816 + '!3d' + 24.829413 + '!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!!2s' + placeName + '!5e0!3m2!1sen!2s!4v1482514462965" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>';
        $('#popup_body').html(PopupBody);
        var footerData = '';
        $('#PopupFooter').html(footerData);
        /* var popupBody = '';
         //Body Setting 
         $('#popup_body').html(popupBody);
         var popupBody = '<div id="dvMap" style="height: 380px; width: 580px;"></div>';
         $('#popup_body').html(popupBody);*/
        var mapOptions = {
         center: new google.maps.LatLng(25.197197, 55.274376),
         zoom: 10,
         mapTypeId: google.maps.MapTypeId.ROADMAP
         }
         var map = new google.maps.Map($("#dvMap")[0], mapOptions);
        }
$(document).ready(function() {

});</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inlineJS'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php
//echo '<pre>';
// print_r($order);
// die();
?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Order Detail</h3>
            </div>


        </div>

        <div class="clearfix"></div>
        <?php echo $__env->make('backend.layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make( 'backend.layouts.popups', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Order Report <small></small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>

                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <!--<div class="col-md-3 col-sm-3 col-xs-12 detail_left">
                            <div class="detail_img">
                                <div id="crop-avatar">
                                   
                                </div>
                            </div>
                            <h3></h3>

                            

                            <br />
                        </div>-->
                        <div class="col-md-9 col-sm-9col-xs-12">



                            <div class="" role="tabpanel" data-example-id="togglable-tabs">
                                <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                                    <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Order Details</a>
                                    </li>
                                    <li role="presentation" class=""><a href="#tab_content3" role="tab" id="detail-tab2" data-toggle="tab" aria-expanded="false">User Details</a>
                                    </li>
<li role="presentation" class=""><a href="#tab_content4" role="tab" id="detail-tab3" data-toggle="tab" aria-expanded="false">
Ordered Items</a>

                                    </li>
                                </ul>
                                <div id="myTabContent" class="tab-content">
                                    <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="   home-tab">

                                        <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th colspan="2" >Order Details</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>No of Items</td>
                                                        <td>
                                                        	<?php
																echo count($order['items'])
															?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Total Amount</td>
                                                        <td><?php echo e($order['total_amount']); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Discount</td>
                                                        <td><?php echo e($order['discount']); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Final Amount</td>
                                                        <td><?php echo e($order['final_amount']); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order Placed On</td>
                                                        <td><?php echo e(Carbon\Carbon::parse($order['created_at'])->format('d-M-Y H:i:s')); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Last Updated</td>
                                                        <td><?php echo e(Carbon\Carbon::parse($order['updated_at'])->format('d-M-Y H:i:s')); ?></td>
                                                        
                                                    </tr>
                                                    
                                                </tbody>
                                            </table>

                                    </div>

                                    <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="detail-tab">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th colspan="2" >Trip Creator</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>First Name</td>
                                                    <td><?php echo e($order['creator']['first_name']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Last Name</td>
                                                    <td><?php echo e($order['creator']['last_name']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Email Address</td>
                                                    <td><?php echo e($order['creator']['email']); ?></td>
                                                </tr>

                                                <tr>
                                                    <td>Address</td>
                                                    <td><?php echo e($order['creator']['address'] != '' ? $order['creator']['address'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>City</td>
                                                    <td><?php echo e($order['creator']['city'] != '' ? $order['creator']['city'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>State</td>
                                                    <td><?php echo e($order['creator']['state'] != '' ? $order['creator']['state'] : 'N/A'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Country</td>
                                                    <td><?php echo e($order['creator']['country'] != '' ? $order['creator']['country'] : 'N/A'); ?></td>
                                                </tr>

                                                <tr>
                                                    <td>Trip Status</td>
                                                    <td><?php echo e($order['creator']['status'] == '1' ? 'Active' : 'Inactive'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Created At</td>
                                                    <td><?php echo e(Carbon\Carbon::parse($order['creator']['created_at'])->format('d-M-Y H:i:s')); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Updated At</td>
                                                    <td><?php echo e(Carbon\Carbon::parse($order['creator']['updated_at'])->format('d-M-Y H:i:s')); ?></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="detail-tab">
                                    <?php foreach( $order['items'] as $allOrderedItems): ?>
                                    
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th colspan="2" ><?php echo e($productDetailsArray[($allOrderedItems['product_id'])]['product_name']); ?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Unit Price</td>
                                                    <td><?php echo e($allOrderedItems['unit_price']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Quantity</td>
                                                    <td><?php echo e($allOrderedItems['quantity']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total Price</td>
                                                    <td><?php echo e($allOrderedItems['total_price']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Sale Price</td>
                                                    <td><?php echo e($allOrderedItems['sale_price']); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Discount Percentage</td>
                                                    <td><?php echo e($allOrderedItems['discount_percentage']); ?>%</td>
                                                </tr>
                                                <tr>
                                                    <td>Created At</td>
                                                    <td><?php echo e(Carbon\Carbon::parse($allOrderedItems['created_at'])->format('d-M-Y H:i:s')); ?></td>
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                    <?php endforeach; ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>