<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('JSLibraries'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('inlineJS'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
            <!------------------------ Header Ends ------------------------------------>

    <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <!------------------------ Content Area ------------------------------------>
    <section class="section contentpages">
        <div class="container">
            <div class="row">
                <h1>Site Information</h1>
                <div class="col-md-12 nopad">
                    <div class="whtbg content-area-1">
                        <h4>INTRODUCTION:</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam venenatis sem at accumsan accumsan. Praesent ut mi ut quam aliquam pharetra. Phasellus accumsan ante ac mattis volutpat. Nunc in varius nulla, vel ullamcorper elit. Aenean vitae odio at justo porttitor pharetra. Aenean varius accumsan nunc, sit amet feugiat urna finibus at. Phasellus pretium lorem a lacus imperdiet, quis hendrerit ligula efficitur. Mauris egestas dictum malesuada. In laoreet dignissim quam, at scelerisque velit accumsan vel. Duis fringilla erat non imperdiet bibendum. Nunc dignissim turpis eget purus efficitur accumsan. Fusce leo nunc, faucibus non dictum sed, consequat nec lacus. Ut accumsan ipsum ut nunc pretium, in elementum massa feugiat. Integer vitae purus erat. Nulla lacinia ornare eros, a scelerisque ante aliquet at.</p>

                        <p> Mauris vestibulum elementum lacus, sit amet dignissim massa condimentum non. Cras viverra condimentum eros eu ornare. Curabitur leo dui, porttitor id pellentesque sit amet, porta nec sapien. Etiam orci mauris, tempus vel eleifend at, condimentum eget tellus. Quisque faucibus blandit sem sit amet molestie. Curabitur eu volutpat est. Aenean et pretium lacus, id pellentesque enim. Maecenas fringilla erat vel enim interdum, ut dignissim mi mattis. Fusce ut porta risus.</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!------------------------ Content Area Ends ------------------------------------>

    <!------------------------ Footer ------------------------------------>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>