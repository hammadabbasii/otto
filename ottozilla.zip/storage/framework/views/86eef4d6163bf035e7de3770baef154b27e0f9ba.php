<?php 


$adminRightsObject	=	array();
$adminRightsObject['category']	=	0;
$adminRightsObject['product']	=	0;
$adminRightsObject['user']	=	0;
$adminRightsObject['cms']	=	0;
$adminRightsObject['noti']	=	0;

 if(isset($admin->rights))
 {
	$adminRightsString	= 	 $admin->rights;
	$adminRightsArray	 =	explode(",",$adminRightsString);
	
	#print_r($adminRightsArray);die();
	if(in_array("category",$adminRightsArray))
	{
		$adminRightsObject['category']	=	1;
	}
	
	if(in_array("product",$adminRightsArray))
	{
		$adminRightsObject['product']	=	1;
	}
	
	if(in_array("user",$adminRightsArray))
	{
		$adminRightsObject['user']	=	1;
	}
	
	if(in_array("cms",$adminRightsArray))
	{
		$adminRightsObject['cms']	=	1;
	}
	
	if(in_array("noti",$adminRightsArray))
	{
		$adminRightsObject['noti']	=	1;
	}
	
 }
 
$adminRightsObject 	=	(object)$adminRightsObject; 
?>
<?php /*
<div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('first_name', 'First Name', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('first_name', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('first_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('last_name', 'Last Name', ['class'=>'control-label'])); ?>

    <?php echo e(Form::text('last_name', old('last_name'), ['class' => 'form-control'])); ?>

    <?php if( $errors->has('last_name') ): ?>
        <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('email', 'Email', ['class'=>'control-label'])); ?>

    <?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

    <?php if( $errors->has('email') ): ?>
        <p class="help-block"><?php echo e($errors->first('email')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('password', 'Password', ['class'=>'control-label'])); ?>

    <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

    <?php if( $errors->has('password') ): ?>
        <p class="help-block"><?php echo e($errors->first('password')); ?></p>
    <?php endif; ?>
</div>




<?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

<?php echo e(Html::link( backend_url('admin'), 'Cancel', ['class' => 'btn btn-default'])); ?>*/ ?>


<div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('first_name', 'First Name *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                 <?php echo e(Form::text('first_name', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('first_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('last_name', 'Last Name', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('last_name', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('last_name') ): ?>
                <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('email', 'Email', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('email', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('email') ): ?>
                <p class="help-block"><?php echo e($errors->first('email')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('password', 'Password', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::password('password',['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('password') ): ?>
                <p class="help-block"><?php echo e($errors->first('password')); ?></p>
        <?php endif; ?>
</div>


<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('Rights', 'Rights', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
        <br />
                <?php echo e(Form::checkbox('rights[]', 'category', $adminRightsObject->category)); ?> Categories  <br />
                <?php echo e(Form::checkbox('rights[]', 'product', $adminRightsObject->product)); ?> Products  <br />
                <?php echo e(Form::checkbox('rights[]', 'user', $adminRightsObject->user)); ?> Users  <br />
                <?php echo e(Form::checkbox('rights[]', 'cms', $adminRightsObject->cms)); ?> CMS Pages  <br />
                <?php echo e(Form::checkbox('rights[]', 'noti', $adminRightsObject->noti)); ?> Notification  <br />
        </div>
        
</div>


<div class="ln_solid"></div>
<div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                <?php echo e(Html::link( backend_url('admin'), 'Cancel', ['class' => 'btn btn-default'])); ?>

        </div>
</div>

