<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('CSSLibraries'); ?>
    <link href="<?php echo e(frontend_asset('css/library.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('JSLibraries'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('inlineJS'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

            <!------------------------ Tagline ------------------------------------>
    <section class="major-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6  col-sm-6"> </div>
                <div class="col-lg-5 col-md-5 hidden-sm hidden-xs nopad"> <span class="hours24" href="javascript:;" title="">Deliver  within 24 Hours </span> <span class="hours24 num" href="javascript:;" title="">800-33257 (deals) </span> </div>
            </div>
        </div>
    </section>
    <!------------------------ Tagline Ends------------------------------------>

    <section class="inner-banner banner-all-categories">
        <h1>ALL CATEGORIES</h1>
        <span>Smarter Shopping,Better Living!</span> </section>
    <section class="container">
        <div class="row">
            <div class="breadcrumbs"><a href="<?php echo e(frontend_url('index')); ?>"> Home</a> All Categories </div>
        </div>
    </section>

    <!------------------------ Content Area ------------------------------------>

    <section class="bx all_cat">
        <div id="groceries_cat" class="container nopad">
            <?php foreach( $allCategoriesFromDB as $category ): ?>
            <div class="cat_large_box whtbg">
                <div class="toparea">

                    <h4><?php echo e($category->category_name); ?></h4>
                    <div class="clear"></div>
                </div>
                <div class="cat_mid_area">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">
                                <ul>
                                    <?php foreach( $category->subcategories as $subcategory ): ?>
                                    <li><a href="<?php echo e(frontend_url('category/'.str_slug($category->id))); ?>"><?php echo e($subcategory->category_name); ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php /*<div class="col-md-4 nopad"> <img  src="" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            </div>
                        </div>
                        <div class="col-md-5"><img style="width:467px ;height:170px ;" src="<?php echo e($category->image); ?>" alt="categoryimage"></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>Houehold & pets</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">General Household</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Cleaner & Polish</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Kitchen Appliances</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Laundry</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Pets</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shoe Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Tissue & Toilet Rolls</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">General Household</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Cleaner & Polish</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Kitchen Appliances</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Laundry</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Pets</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shoe Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Tissue & Toilet Rolls</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">General Household</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Cleaner & Polish</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Kitchen Appliances</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Laundry</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Pets</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shoe Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Tissue & Toilet Rolls</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image2.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>Health</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">Bath</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shower</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Soap</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Deodrants</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Hair Styling</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Dental</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Medicines</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Medicines</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Wellbeing</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Vitamins</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shaving</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Feminine Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Skin Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Eye Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Footcare</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Seasonal</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image3.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>Toiletries</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">Eye Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Footcare</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Seasonal</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Soap</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Deodrants</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Hair Styling</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Dental</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bath</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shower</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Soap</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Deodrants</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Hair Styling</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Dental</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Medicines</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shaving</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Accessories</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Feminine Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Skin Care</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image4.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>snacks</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">Audio Amplifier</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bang & Olufsen</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bose Corporation</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Compact Disc Player</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Headphones</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Microphone</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Music Equipment</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby monitor</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">BeoCom</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Blu-ray</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">List of Blu-ray player</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Blu-ray Disc recordable</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bug zapper</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Home audio</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Audio Amplifier</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bang & Olufsen</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bose Corporation</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Compact Disc Player</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Headphones</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Microphone</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Music Equipment</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image5.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>baby & Child</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Food</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Milk</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Nappies & Wipes</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Skin Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Eye Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bath</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Shower</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Soap</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bottles</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Teats</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Feeding Aids</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Gear</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Care</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Room Decor</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Cream</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Lotion</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Oil</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Powder</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image6.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
            <?php /*<div class="cat_large_box whtbg">*/ ?>
                <?php /*<div class="toparea">*/ ?>
                    <?php /*<h4>toys</h4>*/ ?>
                    <?php /*<div class="clear"></div>*/ ?>
                <?php /*</div>*/ ?>
                <?php /*<div class="cat_mid_area">*/ ?>
                    <?php /*<div class="row">*/ ?>
                        <?php /*<div class="col-md-7">*/ ?>
                            <?php /*<div class="animated fadeInUp wow animated" style="visibility: visible; animation-name: fadeInUp;">*/ ?>
                                <?php /*<ul>*/ ?>
                                    <?php /*<li><a href="javascript::">Arts & Craft Supplies</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Baby Toys</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Bikes</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Scooters</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Ride-ons</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Building Sets & Blocks</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Collectibles</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Creative Toys</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Discovery Toys</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Dolls & Stuffed Animals</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Games & Puzzles</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Musical Instruments</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Outdoor Play</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Pretend Play</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Speciality Toys</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Toddler & Kids</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Vehicale</a></li>*/ ?>
                                    <?php /*<li><a href="javascript::">Race Tracks</a></li>*/ ?>
                                <?php /*</ul>*/ ?>
                                <?php /*<div class="col-md-4 nopad"> <img src="assets/images/banner/all-categories-pic-01.jpg" alt="" class="lazy" width="554" height="202"> </div>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                        <?php /*<div class="col-md-5"><img src="images/cat-image7.jpg" alt="categoryimage"></div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*</div>*/ ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'frontend.layout' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>