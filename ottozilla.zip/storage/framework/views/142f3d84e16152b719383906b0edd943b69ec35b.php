<?php $__env->startSection('title', 'Edit Cms Page'); ?>

<?php $__env->startSection('JSLibraries'); ?>
    <script src="<?php echo e(backend_asset('libraries/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('inlineJS'); ?>

    <script>tinymce.init({ selector:'textarea' });</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Edit User</h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="x_panel">

                        <?php if( $errors->count() ): ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                There was an error while saving your form, please review below.
                            </div>
                        <?php endif; ?>

                        <?php echo $__env->make( 'backend.layouts.notification_message' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <div class="x_title">
                            <h2>Edit Cms Page <small></small></h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br />

                        </div>
<?php //dd($cms); ?>
                        <?php echo Form::model($cms, ['url' => ['backend/cms',$cms->id], 'method' => 'PUT', 'class' => 'form-horizontal form-label-left', 'role' => 'form']); ?>

                        <?php echo $__env->make( 'backend.cms.form' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- /page content -->
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>