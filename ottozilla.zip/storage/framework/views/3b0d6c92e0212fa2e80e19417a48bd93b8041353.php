<?php $__env->startSection('title', 'Update Profile'); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Update Profile</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->

                <?php if( $errors->count() ): ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    There was an error while saving your form, please review below.
                </div>
                <?php endif; ?>

                <?php echo $__env->make( 'backend.layouts.notification_message' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="row">
                    <div class="col-lg-6">
                        <?php echo Form::model($user, ['method' => 'POST', 'class' => '', 'role' => 'form']); ?>

                            <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('first_name', 'First Name', ['class'=>'control-label'])); ?>

                                <?php echo e(Form::text('first_name', null, ['class' => 'form-control'])); ?>

                                <?php if( $errors->has('first_name') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('first_name')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('last_name', 'Last Name', ['class'=>'control-label'])); ?>

                                <?php echo e(Form::text('last_name', old('last_name'), ['class' => 'form-control'])); ?>

                                <?php if( $errors->has('last_name') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('last_name')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('email', 'Email', ['class'=>'control-label'])); ?>

                                <?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

                                <?php if( $errors->has('email') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('email')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <?php echo e(Form::label('password', 'Password', ['class'=>'control-label'])); ?>

                                <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

                                <?php if( $errors->has('password') ): ?>
                                    <p class="help-block"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>

                            <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                            <?php echo e(Html::link( backend_url('/dashboard'), 'Cancel', ['class' => 'btn btn-default'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>

        </div>
        <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>