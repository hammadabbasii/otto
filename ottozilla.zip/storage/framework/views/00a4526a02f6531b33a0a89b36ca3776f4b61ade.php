
<div class="form-group<?php echo e($errors->has('devicetype') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('Platfoem', 'Platform *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                 <?php echo e(Form::select('devicetype', ['android' => 'Android', 'ios' => 'iOS', 'all' => 'All'],null, ['class' => 'form-control col-md-7 col-xs-12','onchange' => 'doSomething(this)'] )); ?>

        </div>
        <?php if( $errors->has('key') ): ?>
                <p class="help-block"><?php echo e($errors->first('key')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('user_id') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('User', 'User *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::select('devicetype', ['android' => 'Edeline Kelvin'],null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('key') ): ?>
                <p class="help-block"><?php echo e($errors->first('key')); ?></p>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('title', 'Title *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('title', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('title') ): ?>
                <p class="help-block"><?php echo e($errors->first('title')); ?></p>
        <?php endif; ?>
</div>


<div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('message', 'Message *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

        <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::text('messaeg', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

        </div>
        <?php if( $errors->has('title') ): ?>
                <p class="help-block"><?php echo e($errors->first('message')); ?></p>
        <?php endif; ?>
</div>



<div class="ln_solid"></div>
<div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                <?php echo e(Form::submit('Send', ['class' => 'btn btn-primary'])); ?>

                <?php echo e(Html::link( backend_url('push/send'), 'Cancel', ['class' => 'btn btn-default'])); ?>

        </div>
</div>

