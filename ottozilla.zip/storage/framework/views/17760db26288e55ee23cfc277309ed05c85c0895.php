<?php /*




<?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

<?php echo e(Html::link( backend_url('product'), 'Cancel', ['class' => 'btn btn-default'])); ?>*/ ?>

<div class="form-group<?php echo e($errors->has('CategoryId') ? ' has-error' : ''); ?>">
    <?php echo e(Form::Label('CategoryId', 'Select Category:' , ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <select class="form-control col-md-7 col-xs-12" name="CategoryId">

        <?php
        if (isset($product->id)) {
            $thisParentId = $product->CategoryId;

            foreach ($category as $item) {
                $thisCategoryId = $item->id;
                if ($thisCategoryId == $thisParentId) {
                    echo '<option value="' . $item->id . '" selected>' . $item->CategoryName . '</option>';
                } else {
                    echo '<option value="' . $item->id . '">' . $item->CategoryName . '</option>';
                }
            }
        } else {
            foreach ($category as $item) {

                echo '<option value="' . $item->id . '">' . $item->CategoryName . '</option>';
            }
        }
        ?>

    </select>
</div>

<div class="form-group<?php echo e($errors->has('ProductName') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('ProductName', 'Product Name *', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::text('ProductName', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

    </div>
    <?php if( $errors->has('ProductName') ): ?>
    <p class="help-block"><?php echo e($errors->first('ProductName')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('ProductDescription') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('ProductDescription', 'Product Description', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::textArea('ProductDescription', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

    </div>
    <?php if( $errors->has('ProductDescription') ): ?>
    <p class="help-block"><?php echo e($errors->first('ProductDescription')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('Price') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('Price', 'Price', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::text('Price', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

    </div>
    <?php if( $errors->has('Price') ): ?>
    <p class="help-block"><?php echo e($errors->first('Price')); ?></p>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('Quantity') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('Quantity', 'Quantity', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::text('Quantity',null,['class' => 'form-control col-md-7 col-xs-12'])); ?>

    </div>
    <?php if( $errors->has('Quantity') ): ?>
    <p class="help-block"><?php echo e($errors->first('Quantity')); ?></p>
    <?php endif; ?>
</div>


<div class="form-group<?php echo e($errors->has('ProductImage') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('ProductImage', 'Product Image', ['class'=>'control-label col-md-3 col-sm-3 col-xs-12'])); ?>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php echo e(Form::file('ProductImage', null, ['class' => 'form-control col-md-7 col-xs-12'])); ?>

    </div>
    <?php if( $errors->has('ProductImage') ): ?>
    <p class="help-block"><?php echo e($errors->first('ProductImage')); ?></p>
    <?php endif; ?>
</div>


<div class="ln_solid"></div>
<div class="form-group">
    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
        <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

        <?php echo e(Html::link( backend_url('product'), 'Cancel', ['class' => 'btn btn-default'])); ?>

    </div>
</div>

