<?php $__env->startSection('title', 'Reports'); ?>

<?php $__env->startSection('CSSLibraries'); ?>
    <!-- DataTables CSS -->
    <link href="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSLibraries'); ?>
    <!-- DataTables JavaScript -->
    <script src="<?php echo e(backend_asset('libraries/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(backend_asset('libraries/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(backend_asset('libraries/datatables-responsive/dataTables.responsive.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inlineJS'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true,

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Reports</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">

                <?php echo $__env->make( 'backend.layouts.notification_message' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="panel panel-default">
                    <!-- <div class="panel-heading">
                        Users
                    </div> -->
                    <!-- /.panel-heading -->

                    <?php echo $__env->make('backend.layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="panel-body">
                        <table width="100%" class="table table-striped table-bordered table-hover datatable" id="dataTables-example" data-column-defs='[{"sortable": false, "targets": [-1]}]'>
                            <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Report Type</th>
                                <th>Date</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th class="w-50">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach( $reports as $record ): ?>
                                <tr class="">
                                    <td><?php echo e(rtrim($record->first_name . ' ' . $record->last_name)); ?></td>
                                    <td><?php echo e($record->report_type); ?></td>
                                    <td><?php echo e($record->date); ?></td>
                                    <td><?php echo e($record->start_time); ?></td>
                                    <td><?php echo e($record->end_time); ?></td>
                                    <td>
                                        <?php echo Form::model($record, ['method' => 'delete', 'url' => 'backend/report/'.$record->id, 'class' =>'form-inline form-delete']); ?>

                                        <?php echo Form::hidden('id', $record->id); ?>

                                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['class' => 'btn btn-xs btn-danger delete', 'name' => 'delete_modal', 'type' => 'submit']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'backend.layouts.app' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>