<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Ad extends Authenticatable {

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'user_id', 'category_id', 'title', 'description', 'phone_number', 'price', 'year', 'is_featured'
    ];
    protected $appends = ['ad_image'];

    public function images() {
        return $this->hasMany('App\Adimage', 'ad_id');
    }

    public function imagesToArray() {
        $arr = [];

        foreach ($this->images as $image) {

            $arr[] = asset('public/' . Config::get('constants.front.dir.adsPicPath') . ($image->ad_image ?: Config::get('constants.front.default.profilePic')));
        }
        return $arr;
    }

    public function getAdImageAttribute() {
        return $this->imagesToArray();
    }

}
