<?php

namespace App\Http\Controllers;

use App\Http\Requests\Frontend\WebContactRequest;
use App\Http\Requests\Frontend\WebJoinRequest;
use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Request;
use Hash;
use Auth;
use Gregwar\Image\Image;
use Illuminate\Support\Facades\Session;
use JWTAuth;
use App\Setting;
use App\Useraddress;
use App\Userorder;
use App\Report;
use App\Helpers\RESTAPIHelper;
use Config;
use Validator;
use App\Http\Requests\Frontend\WebLoginRequest;
use App\Http\Requests\Frontend\AddressRequest;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use App\User;
use App\Feedback;
use App\Usercart;
use App\Slider;
use App\Category;
use App\Advertisementimage;

class WebController extends Controller {

    public function login(WebLoginRequest $request) {
        
        $postData = $request->all();
        //dd($postData['email']);
        $data = User::where('email', $postData['email'])->first();
        if ($data) {
            $check = Hash::check($postData['password'], $data['password']);
            if ($check) {
                $user = User::where('email', $postData['email'])->first();
//                dd($user);
                $request->session()->put('user', $user);
                //session()->flash('alert', 'These credentials do not match our records.');
                return redirect('index');
            } else {

                Session::put('fail', 'Invalid Credentials!');
                return redirect('login');
            }
        } else {
            Session::put('fail', 'Invalid Credentials!');
            return redirect('login');
        }
    }

    public function search(Request $request) {
        $data = $request->all();
        $category = $data['category_id'];
        $Category = Category::where('parent_id', 0)->whereId($category)->with('subcategories.brands')->first();
        $allCategoriesFromDB = Category::where('parent_id', 0)->with('subcategories')->get();
        return frontend_view('categories', compact('Category', 'allCategoriesFromDB'));
    }

    public function sendemail(Request $request) {
        $postData = $request->all();
        $requestuser = User::where('email', $postData['email'])->first();
        if (!$requestuser) {
            return redirect('forgotpassword');
        }
        //dd($requestuser);
        $passwordGenerated = \Illuminate\Support\Str::random(12);

        $requestuser->password = \Hash::make($passwordGenerated);
        $requestuser->save();

        $emailBody = "You have requested to reset a password of your account, please find your new generated password below:

            New Password : " . $passwordGenerated . "

            Thanks.";
        \Mail::raw($emailBody, function($m) use($requestuser) {
            $m->to($requestuser->email)->from(env('MAIL_USERNAME'))->subject('Your password has been reset -Smart Mart');
        });

        return redirect('login');
    }

    public function addtocart(Request $request) {
        $postData = $request->all();
        $user_id = $postData['user_id'];
        $product_id = $postData['product_id'];
        //dd($user_id." ".$product_id);
        $alreadycart = Usercart::where('user_id', $user_id)->where('product_id', $product_id)->first();
        if (!$alreadycart) {
            $addcart = Usercart::create(['user_id' => $user_id, 'product_id' => $product_id, 'quantity' => 1]);
        }

        $slider = Slider::all();
        $allCategoriesFromDB = Category::where('parent_id', 0)->with('subcategories')->get();
        $advertisement = Advertisementimage::all();
        return frontend_view('index', compact('slider', 'allCategoriesFromDB', 'advertisement'));
    }

    public function newsmail(Request $request) {
        $postData = $request->all();
//        $requestuser=User::where('email',$postData['newsletter'])->first();
        //dd($requestuser);
//        $passwordGenerated = \Illuminate\Support\Str::random(12);
//        $requestuser->password = \Hash::make( $passwordGenerated );
//        $requestuser->save();

        $emailBody = "News Letter Here!!!

            Thanks.";
//        \Mail::raw( $emailBody, function($m) use($requestuser) {
//            $m->to($requestuser->email)->from( env('MAIL_USERNAME') )->subject('News Letter -Smart Mart');
//        });

        return redirect('index');
    }

    public function add(WebJoinRequest $request, User $user) {
        $postData = $request->all();
        //dd($request->hasFile('image'));
        if ($request->has('password') && $request->get('password', '') != '') {
            $postData['password'] = \Hash::make($postData['password']);
        }

        if ($file = $request->hasFile('image')) {


            $file = $request->file('image');

            $fileName = Str::random(12) . '.' . $request->file('image')->getClientOriginalExtension();
            $destinationPath = Config::get('constants.front.dir.profilePicPath');
            $file->move($destinationPath, $fileName);

            if (Image::open($destinationPath . '/' . $fileName)->save($destinationPath . '/' . $fileName)) {
                $postData['image'] = $fileName;
            }
        }
        $user->create($postData);
        return redirect('index');
    }

    public function addAddress(AddressRequest $request, Useraddress $useradd) {
        $user = session()->get('user');
        $postData = $request->all();
        $postData['user_id'] = $user->id;
        if ($request->has('check')) {
            $data = $useradd->create($postData);
            $adressId = $data->id;
            $request->session()->put('addressId', $adressId);
            return redirect('checkout');
        }
        return redirect('checkout');
    }

    public function contactadd(WebContactRequest $request, Feedback $feedback) {
        $postData = $request->all();
//        dd($postData);
        $feedback->create($postData);
        return redirect('contactus');
    }

    public function addOrder(Request $request) {
        $input = $request->all();
        extract($input);
        //$userId = $request->input('userId');
        // dd($input);
        # header('Content-type: application/json');

        $blankObject = (object) array();

        if (!isset($user_id) || trim($user_id) == '') {
            return RESTAPIHelper::response($blankObject, 'Error', 'Please Enter user_id');
        } elseif (!isset($items_ids) || trim($items_ids) == '') {
            return RESTAPIHelper::response($blankObject, 'Error', 'Please Enter items_ids');
        } elseif (!isset($quantities) || trim($quantities) == '') {
            return RESTAPIHelper::response($blankObject, 'Error', 'Please Enter quantities');
        } elseif (!isset($address_id) || trim($address_id) == '') {
            return RESTAPIHelper::response($blankObject, 'Error', 'Please Enter address_id');
        } elseif (!isset($payment_method) || trim($payment_method) == '') {
            return RESTAPIHelper::response($blankObject, 'Error', 'Please Enter payment_method');
        }

        $shipping_address = $this->GetThisAddress($address_id);
        #Marking all addresses as 0; not selected;
        DB::table('user_address')->where('user_id', $user_id)->update(['is_selected' => 0]);
        #Marking this as primary address
        DB::table('user_address')->where('id', $address_id)->update(['is_selected' => 1]);

        #Now getting the selected address, this will also mark it as primary
        $input['shipped_to_address'] = json_encode($shipping_address);

        //dd($input);

        $orderId = Userorder::create($input)->id; // DB::table('userorders')->insertGetId($input);

        $totalAmountOfOrder = $totalDiscountedAmountOfOrder = $promotionId = 0;
        $promotionIdsArray = array();
        $productsIdsArray = explode(",", $items_ids);
        $productsQuantitiessArray = explode(",", $quantities);



        $productDiscountsArray = array();


        #Getting Product wise Discount rate
        /* $allProductsDiscountsDB = DB::table('promotion_items')->whereIn('product_id', $productsIdsArray)->get(['id', 'promotion_id', 'product_id', 'discount_percentage']);
          foreach($allProductsDiscountsDB as $eachProductDiscount)
          {

          $eachProductDiscount	=	(array)$eachProductDiscount;




          $thisProductId		  =	$eachProductDiscount['product_id'];
          $thisProductDiscount	=	$eachProductDiscount['discount_percentage'];
          $promotionIdsArray[$thisProductId]		=	$eachProductDiscount['promotion_id'];
          $productDiscountsArray[$thisProductId]	=	$thisProductDiscount;
          } */

        ##Get Selected Produtcs; to get Price etc
        $allProductsFromDB = DB::table('products')->whereIn('id', $productsIdsArray)->get(['id', 'product_name', 'price', 'quantity', 'shipping_cost']);


        $productDetailsArray = array();
        foreach ($allProductsFromDB as $eachProduct) {
            $eachProduct = (array) $eachProduct;
            $thisProductId = $eachProduct['id'];
            $productDetailsArray[$thisProductId] = $eachProduct;
        }

//dd($productsIdsArray);
        $dataForOrderedItems = array();
        $arrayCounter = 0;
        foreach ($productsIdsArray as $eachBoughtProduct) {


            $tempPrice = isset($productDetailsArray[$eachBoughtProduct]['price']) ? $productDetailsArray[$eachBoughtProduct]['price'] : 0;  #Unit price of this item
            $tempQuantity = $productsQuantitiessArray[$arrayCounter];     #Quantity Selected to buy
            $itemAmount = $tempPrice * $tempQuantity;


            $orderedItem = array();
            $orderedItem['order_id'] = $orderId;
            $orderedItem['product_id'] = $eachBoughtProduct;
            $orderedItem['unit_price'] = $tempPrice;
            $orderedItem['quantity'] = $tempQuantity;

            $orderedItem['sale_price'] = $itemAmount;
            $orderedItem['total_price'] = $itemAmount;
            $orderedItem['discount_percentage'] = 0;
            $orderedItem['promotion_id'] = 0;

            $totalAmountOfOrder += $orderedItem['sale_price'];

            #Checking Discount on this particular product
            /* if(isset($productDiscountsArray[$eachBoughtProduct]))
              {
              $discountedPricePercentage	=	$productDiscountsArray[$eachBoughtProduct];	#Availble Discount on this product

              #Unit Price  x Quantity x (1 -  discount Percentage)
              $discountedPriceOfProduct	=	$itemAmount * (1-(($discountedPricePercentage)/100))	;

              $orderedItem['sale_price']			=	$discountedPriceOfProduct;
              $orderedItem['discount_percentage']   =	$discountedPricePercentage;
              $orderedItem['promotion_id'] 		  =	$promotionIdsArray[$eachBoughtProduct];
              } */

            $totalDiscountedAmountOfOrder += $orderedItem['sale_price'];
            $dataForOrderedItems[] = $orderedItem;

            $arrayCounter++;
        }

        // dd($dataForOrderedItems);
        #Adding Ordered Items to DB
        DB::table('orderitems')->insert($dataForOrderedItems);

        #Updating Total Amount Of Order
        DB::table('userorders')->where('id', $orderId)->update(['total_amount' => $totalAmountOfOrder, 'discount' => ($totalAmountOfOrder - $totalDiscountedAmountOfOrder), 'final_amount' => $totalDiscountedAmountOfOrder]);

        $input['shipped_to_address'] = ($shipping_address);

//        return RESTAPIHelper::response($input,'Success', 'Order placed');
        $user = $request->session()->get('user');
        Usercart::where('user_id', $user->id)->delete();
        return redirect('orders');
    }

    function GetThisAddress($address_id) {
        $addresses = Useraddress::where('id', $address_id)->first();

        return $addresses;
    }

}
